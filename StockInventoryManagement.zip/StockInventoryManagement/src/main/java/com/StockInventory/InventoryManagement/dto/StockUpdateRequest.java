package com.StockInventory.InventoryManagement.dto;

import lombok.Data;

@Data
public class StockUpdateRequest {
    private int quantityChange;
}
