package com.StockInventory.InventoryManagement.exception;

public class AuthenticationFailureException extends RuntimeException{

	public AuthenticationFailureException(String message) {
		super(message);
	}
}
