package com.StockInventory.InventoryManagement.service;

import com.StockInventory.InventoryManagement.dto.ProductDTO;
import com.StockInventory.InventoryManagement.entity.Product;
import com.StockInventory.InventoryManagement.entity.StockHistory;
import com.StockInventory.InventoryManagement.repository.ProductRepository;
import com.StockInventory.InventoryManagement.repository.StockHistoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final StockHistoryRepository stockHistoryRepository;

    // ✅ Create Product using DTO
    public Product createProduct(ProductDTO dto) {
        Product product = new Product();
        product.setName(dto.getName());
        product.setCategory(dto.getCategory());
        product.setBrand(dto.getBrand());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setQuantity(dto.getQuantity());
        product.setMinStockLevel(dto.getMinStockLevel());
        product.setCreatedAt(LocalDateTime.now());
        product.setUpdatedAt(LocalDateTime.now());
        return productRepository.save(product);
    }

    // ✅ Get all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // ✅ Get product by ID
    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + id));
    }

    // ✅ Update product
    public Product updateProduct(Long id, Product updatedProduct) {
        Product product = getProductById(id);
        product.setName(updatedProduct.getName());
        product.setDescription(updatedProduct.getDescription());
        product.setPrice(updatedProduct.getPrice());
        product.setCategory(updatedProduct.getCategory());
        product.setBrand(updatedProduct.getBrand());
        product.setQuantity(updatedProduct.getQuantity());
        product.setMinStockLevel(updatedProduct.getMinStockLevel());
        product.setUpdatedAt(LocalDateTime.now());
        return productRepository.save(product);
    }

    // ✅ Delete product
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    // ✅ Update Stock (Add/Remove)
    @Transactional
    public void updateStock(Long productId, Integer quantityChange, String actionType, String updatedBy) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + productId));

        if ("ADD".equalsIgnoreCase(actionType)) {
            product.setQuantity(product.getQuantity() + quantityChange);
        } else if ("REMOVE".equalsIgnoreCase(actionType)) {
            if (product.getQuantity() < quantityChange) {
                throw new RuntimeException("Insufficient stock to remove");
            }
            product.setQuantity(product.getQuantity() - quantityChange);
        } else {
            throw new RuntimeException("Invalid action type: must be ADD or REMOVE");
        }

        product.setUpdatedAt(LocalDateTime.now());
        productRepository.save(product);

        // ✅ Save stock history
        StockHistory history = new StockHistory();
        history.setProduct(product);
        history.setQuantityChange(quantityChange);
        history.setActionType(actionType);
        history.setUpdatedBy(updatedBy);
        history.setUpdatedAt(LocalDateTime.now());
        stockHistoryRepository.save(history);
    }

    // ✅ Get Stock History by Product ID
    public List<StockHistory> getHistoryByProductId(Long productId) {
        return stockHistoryRepository.findByProductId(productId);
    }

    // ✅ Get Low Stock Products
    public List<Product> getLowStockProducts(Integer threshold) {
        return productRepository.findAll().stream()
                .filter(p -> p.getQuantity() != null && p.getQuantity() < threshold)
                .toList();
    }
}
