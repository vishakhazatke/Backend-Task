
package com.StockInventory.InventoryManagement.controller;

import com.StockInventory.InventoryManagement.entity.TransactionLog;
import com.StockInventory.InventoryManagement.service.TransactionLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionLogController {

    private final TransactionLogService transactionLogService;

    // Get logs by product
    @GetMapping("/{productId}")
    public ResponseEntity<List<TransactionLog>> getLogsByProduct(@PathVariable Long productId) {
        List<TransactionLog> logs = transactionLogService.getLogsByProductId(productId);
        return ResponseEntity.ok(logs);
    }
}
