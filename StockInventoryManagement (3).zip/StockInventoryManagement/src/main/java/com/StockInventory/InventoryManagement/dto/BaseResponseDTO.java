package com.StockInventory.InventoryManagement.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseResponseDTO<T> {
    private String status; // SUCCESS or ERROR
    private String message;
    private T data;
    private LocalDateTime timestamp = LocalDateTime.now();
    
	public BaseResponseDTO(String status, String message, T data) {
		this.status = status;
		this.message = message;
		this.data = data;
		this.timestamp = LocalDateTime.now();
	}    
}
