package com.StockInventory.InventoryManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.StockInventory.InventoryManagement.entity.Product;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategory(String category);
    List<Product> findByBrand(String brand);
    List<Product> findByQuantityLessThan(Integer threshold);

}
