package com.StockInventory.InventoryManagement.mapper;

import com.StockInventory.InventoryManagement.dto.ProductDTO;
import com.StockInventory.InventoryManagement.dto.UserDTO;
import com.StockInventory.InventoryManagement.entity.Product;
import com.StockInventory.InventoryManagement.entity.User;

public class Mapper {
    public static UserDTO toUserDTO(User user){
        if(user == null) return null;
        return new UserDTO(
                user.getName(),
                user.getEmail(),
                user.getMobileNo(),
                user.getAddress(),
                user.getRole() != null ? user.getRole().getName() : null
        );
    }

    public static ProductDTO toProductDTO(Product product){
        if(product == null) return null;
        return new ProductDTO(
                product.getName(),
                product.getCategory(),
                product.getBrand(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity(),
                product.getMinStockLevel()
        );
    }

    public static Product toProductEntity(ProductDTO dto){
        if(dto == null) return null;
        Product p = new Product();
        p.setName(dto.getName());
        p.setCategory(dto.getCategory());
        p.setBrand(dto.getBrand());
        p.setDescription(dto.getDescription());
        p.setPrice(dto.getPrice());
        p.setQuantity(dto.getQuantity());
        p.setMinStockLevel(dto.getMinStockLevel());
        return p;
    }
}
