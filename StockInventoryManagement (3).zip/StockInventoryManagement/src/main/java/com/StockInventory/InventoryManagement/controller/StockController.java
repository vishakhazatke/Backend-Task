package com.StockInventory.InventoryManagement.controller;

import com.StockInventory.InventoryManagement.dto.StockUpdateDTO;
import com.StockInventory.InventoryManagement.entity.StockHistory;
import com.StockInventory.InventoryManagement.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/stock")
@RequiredArgsConstructor
public class StockController {

    private final ProductService productService;
    //private final StockHistoryService stockHistoryService;

    // ✅ Ticket 13: Update Stock API
    @PutMapping("/update/{productId}")
    public String updateStock(@PathVariable Long productId,
                              @RequestBody StockUpdateDTO dto,
                              @RequestHeader("Authorization") String token) {
        String updatedBy = token.substring(7); // For simplicity, using token directly. Later we can extract user email.
        productService.updateStock(productId, dto.getQuantityChange(), dto.getActionType(), updatedBy);
        return "Stock updated successfully!";
    }

    // ✅ Ticket 14: Get Stock History API (All Roles)
    @GetMapping("/history/{productId}")
    public ResponseEntity<?> getStockHistory(@PathVariable Long productId) {
        return ResponseEntity.ok(productService.getHistoryByProductId(productId));
    }

}
