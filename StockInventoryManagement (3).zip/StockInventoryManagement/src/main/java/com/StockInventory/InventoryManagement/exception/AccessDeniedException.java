package com.StockInventory.InventoryManagement.exception;

public class AccessDeniedException extends RuntimeException{

	public AccessDeniedException(String message) {
		super(message);
	}
}
