package com.StockInventory.InventoryManagement.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleResourceNotFound(ResourceNotFoundException ex){
		Map<String, Object> response = new HashMap<>();
		response.put("status", "ERROR");
		response.put("message", ex.getMessage());
		response.put("timestamp", LocalDateTime.now());
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(InvalidInputException.class)
	public ResponseEntity<Map<String, Object>> handleInvalidInput(InvalidInputException ex){
		Map<String, Object> response = new HashMap<>();
		response.put("status", HttpStatus.BAD_REQUEST.value());
		response.put("message", ex.getMessage());
		response.put("timestamp", LocalDateTime.now());
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

	}
	@ExceptionHandler(AuthenticationFailureException.class)
	public ResponseEntity<Map<String, Object>> handleAuthFailure(AuthenticationFailureException ex){
		Map<String, Object> response = new HashMap<>();
		response.put("status", HttpStatus.UNAUTHORIZED.value());
		response.put("message", ex.getMessage());
		response.put("timestamp", LocalDateTime.now());
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

	}
	
	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<Map<String, Object>> handleAccessDenied(AccessDeniedException ex){
		Map<String, Object> response = new HashMap<>();
		response.put("status", HttpStatus.FORBIDDEN.value());
		response.put("message", ex.getMessage());
		response.put("timestamp", LocalDateTime.now());
		return new ResponseEntity<>(response, HttpStatus.FORBIDDEN);

	}
	

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Map<String, Object>> handleGeneral(Exception ex){
		Map<String, Object> response = new HashMap<>();
		response.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
		response.put("message", ex.getMessage());
		response.put("timestamp", LocalDateTime.now());
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

	}
}
