package com.StockInventory.InventoryManagement.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class StockHistoryDTO {

	private Long id;
	private Integer quantityChange;
	private String actionType;
	private String updatedBy;
	private LocalDateTime updatedAt;
}
