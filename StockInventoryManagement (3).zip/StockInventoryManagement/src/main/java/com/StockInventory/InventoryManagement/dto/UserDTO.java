package com.StockInventory.InventoryManagement.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    private String name;
    private String email;
    private String mobileNo;
    private String address;
    private String roleName;
}
