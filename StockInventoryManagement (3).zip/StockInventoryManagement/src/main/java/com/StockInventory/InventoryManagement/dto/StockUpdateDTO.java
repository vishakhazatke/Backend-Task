
package com.StockInventory.InventoryManagement.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockUpdateDTO {
    private Integer quantityChange;
    private String actionType; // "ADD" or "REMOVE"
}
