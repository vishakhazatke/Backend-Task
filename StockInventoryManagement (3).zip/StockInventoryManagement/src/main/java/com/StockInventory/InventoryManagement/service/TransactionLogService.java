
package com.StockInventory.InventoryManagement.service;

import com.StockInventory.InventoryManagement.entity.TransactionLog;
import com.StockInventory.InventoryManagement.repository.TransactionLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionLogService {

    private final TransactionLogRepository transactionLogRepository;

    public void saveTransactionLog(Long productId, Long userId, String changeType, Integer quantityChanged) {
        TransactionLog log = new TransactionLog();
        log.setProductId(productId);
        log.setUserId(userId); // <-- now Long, no error
        log.setChangeType(changeType);
        log.setQuantityChanged(quantityChanged);
        log.setCreatedAt(LocalDateTime.now());

        transactionLogRepository.save(log);
    }


    // Get all logs for a product
    public List<TransactionLog> getLogsByProductId(Long productId) {
        return transactionLogRepository.findByProductId(productId);
    }
}
