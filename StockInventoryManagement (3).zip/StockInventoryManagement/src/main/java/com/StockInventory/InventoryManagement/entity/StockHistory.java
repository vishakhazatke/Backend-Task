package com.StockInventory.InventoryManagement.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Relation with Product
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "product_id", nullable = false)
    @JsonIgnore
    private Product product;

    private Integer quantityChange;  // ✅ Track quantity change
    private String actionType;       // ✅ e.g. "ADD" or "REMOVE"
    private String updatedBy;        // ✅ e.g. "Admin"
    private LocalDateTime updatedAt; // ✅ Track when stock was updated
}
