package com.StockInventory.InventoryManagement.controller;

import com.StockInventory.InventoryManagement.entity.User;
import com.StockInventory.InventoryManagement.repository.RoleRepository;
import com.StockInventory.InventoryManagement.repository.UserRepository;
import com.StockInventory.InventoryManagement.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody Map<String, String> userData) {
        User user = new User();
        user.setName(userData.get("name"));
        user.setEmail(userData.get("email"));
        user.setPassword(passwordEncoder.encode(userData.get("password")));
        user.setMobileNo(userData.get("mobileNo"));
        user.setAddress(userData.get("address"));
        user.setStatus("ACTIVE");

        user.setRole(roleRepository.findByName(userData.get("role")).orElseThrow());

        userRepository.save(user);
        return "User registered successfully!";
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> loginData) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginData.get("email"),
                        loginData.get("password")
                )
        );

        User user = userRepository.findByEmail(loginData.get("email")).orElseThrow();

        UserDetails userDetails = new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(),
                user.getRole() == null ? java.util.Collections.emptyList()
                                       : java.util.Collections.singleton(
                                             new org.springframework.security.core.authority.SimpleGrantedAuthority(user.getRole().getName())
                                       )
        );

        return jwtUtil.generateToken(userDetails);

    }
}
